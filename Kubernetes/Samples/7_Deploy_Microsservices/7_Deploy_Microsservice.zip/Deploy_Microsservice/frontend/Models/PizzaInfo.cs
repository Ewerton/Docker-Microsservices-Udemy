﻿namespace frontend.Models;

public class PizzaInfo
{
    public string? PizzaNome { get; set; }
    public decimal PizzaPreco { get; set; }
    public string? Ingredientes { get; set; }
    public string? EmEstoque { get; set; }
}
